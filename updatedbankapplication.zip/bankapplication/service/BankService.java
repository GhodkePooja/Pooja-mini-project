package com.bankapplication.service;

public interface BankService {
public void createBankAccount();
public void viewAccountDetails();
public void withdrawMoney();
public void depositMoney();
public void updateAccountDetails();
public void viewAccountBalance();
}
